"use client"

import FloatingBubblesBackground from "../components/floating-bubbles"

export default function Page() {
  return <FloatingBubblesBackground title="Leetcode Stats" />
}
